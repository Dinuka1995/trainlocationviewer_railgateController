
<!DOCTYPE html>
<html>
<head>
	<title></title>

	<meta name="viewport" content="width=device-width, initial-scale=1.0"> 
      <!-- Bootstrap --> 
	<link href="css/bootstrap.min.css" rel="stylesheet"> 
</head>
<body>
		
<nav class="navbar navbar-inverse"  >  
  <div class="container-fluid">  
    <div class="navbar-header">  
      <a class="navbar-brand" href="#">Union</a>  
    </div>  
    <ul class="nav navbar-nav" >  
      <li><a href="logged_in.php">Home</a></li>  
      <li><a href="profile.php">Profile</a></li>  
      <li><a href="#">Page 2</a></li>  
      <li><a href="#">Page 3</a></li>  
    </ul>  
    <div>
    	<p class="navbar-text navbar-right" style="margin-right: 10px;"><a  href="sign_in1.php">sign out</a></p>
    </div>
  </div>  
</nav>  
 

</body>
</html>