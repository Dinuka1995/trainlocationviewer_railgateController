

This is the project 1.1 which used ajax for load locations. next version is adding multiple 

markers on the map (project1.2). We will meet with that version! -_- ;
