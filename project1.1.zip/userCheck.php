
<?php include('connect.php'); ?>

<?php
	$userName=$_POST['userName'];
	$password=$_POST['password'];
	$Que="SELECT password from controllers where username='$userName'";

	$mySql=mysqli_query($dbc,$Que);
	$num=mysqli_num_rows($mySql);
	//echo $num;
	$row = mysqli_fetch_row($mySql);
	//check resulds are null
	if(!$num==0){
		// echo $row[0];
		 //check given password correct
		if($password==$row[0]){
			setcookie('userName',$userName,time()+60*60*24*7);
			session_start();
			$_SESSION['userName']=$userName;
			echo "<script> window.location.replace('index1.php') </script>"  ;
		}else{
 
			echo "<script> window.location.replace('index.php') </script>"  ;
		}
	}else{
		echo "<script> window.location.replace('index.php') </script>"  ;
	}

?>