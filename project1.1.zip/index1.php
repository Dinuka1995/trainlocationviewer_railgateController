<!DOCTYPE html>
<html>
  <head>

   <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
      <!-- Bootstrap --> 
  <link href="css/bootstrap.min.css" rel="stylesheet"> 

    <style>
      #map {
        height: 400px;
        width: 100%;
       }

       body{
          background: lightblue;
       }
    </style>

  </head>
  <body>
    <div class="heading">
      		<img src="images/top_bar_bg.jpg" class="img-thumbnail">
   	</div>
    <h2 style="color:blue; padding-left: 100px;">Train Location viewer</h2>
    <div id="map">
      
    </div>
    <br>
    <div class="row">
        <form method="" action="index.php">
          <button id="location" class="btn btn-primary">back</button>
        </form>
    </div>
    <br><br>
     
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDyinR8VdEMxjFVYNNCQgn-clAObyvty88"
     type="text/javascript">
    </script>
    <script>
      
        var uluru = {lat:  7.2681, lng: 80.6851};// 7.2681, 80.6851

        var map = new google.maps.Map(document.getElementById('map'), {
          zoom: 15,
          center: uluru
        });
        var marker = new google.maps.Marker({
          position: uluru,
          map: map
        });


      // var repeater;
      // var commentsCount=1;
      
      // function doWork(){
      //   var lat=6.928110;
      //   var lng= 79.858576;
      //   var location1=new google.maps.LatLng(lat,lng);
      //   alert(location1)

      //   map.setCenter(location1);
      //   marker.setPosition(location1);
      //   commentsCount++;
      //   repeater =setTimeout(doWork, 5000);

      // };
      // doWork();

      var repeater;
  function myFunction(){

    var ajax= new XMLHttpRequest();
    var method ="GET";
    var url="data.php";
    var asynchronous=true;

    ajax.open(method,url,asynchronous);

    ajax.send();
    
    ajax.onreadystatechange =function (){
    
    if(this.readyState==4&& this.status==200){
      var data=JSON.parse(this.responseText);
      console.log(data[data.length-1].lng);
      var lat=data[data.length-1].lng;
      var lng= data[data.length-1].lat;
      var location1=new google.maps.LatLng(lat,lng);

      map.setCenter(location1);
      marker.setPosition(location1);
      
    }
    }
    
    repeater =setTimeout(myFunction, 5000);
  }


  myFunction();


    </script>
   
  </body>
</html>