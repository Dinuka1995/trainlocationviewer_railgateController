 
<!DOCTYPE html>
<html>
<head>

  <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
      <!-- Bootstrap --> 
  <link href="css/bootstrap.min.css" rel="stylesheet"> 

  
  
   


  <title>controllers</title>
</head>
<body style="background: #9FEDD5;">

    <div class="heading">
      <img src="images/top_bar_bg.jpg" class="img-thumbnail">
    </div>

    <div class="container-fluid">
    <br>

    <div class="row">
      <div class="col-md-3">
        
      </div>
      <div class="col-md-6">
        <h3>Controllers</h3>
      </div>
      <div class="col-md-3"></div>

    </div>
    

      <table class="table  table-hover">

      <div class="col-md-2">
        
      </div>
      <div class=" table-responsive col-md-8">

      <br>
      <br>
      
       
      <thead>
        
        <tr style="background: #276D80;">
          <th>User Name</th>
          <th>ID number</th>
          <th>Age</th>
          <th>Email</th>
          <th>Position</th>
          <th>Status</th>
        </tr> 
      </thead>
      <div id="tbl_row">

        <form method="POST" action="">

         
          <tbody>
          
            <?php 
            $servername = "localhost";
            $username = "root";
            $password = "";
            $dbname = "gps";
            // Create connection
            $conn = new mysqli($servername, $username, $password, $dbname);
            // Check connection
            if ($conn->connect_error) {
               die("Connection failed: " . $conn->connect_error);
            } 

            $sql = "SELECT id, username, email,age,nic,position FROM controllers";
            $result = $conn->query($sql);

             
            // Check connection
             if ($result->num_rows > 0) {
                // output data of each row
                while($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>".$row["username"]."</td>";
                    echo "<td>".$row["nic"]."</td>";
                    echo "<td>".$row["age"]."</td>";
                    echo "<td>".$row["email"]."</td>";
                    echo "<td>".$row["position"]."</td>";
                    echo "<td>"."<label><input type='checkbox'" .">Accept"."</label>"." </td>";
                    echo "</tr>";
                    //echo "<td>"."<label><input type="checkbox" value="">Accept</label>"." </td>";
                    //echo "<td>nic</td>";
                    //echo "id: " . $row["id"]. " - Name: " . $row["username"]. "<b> email : </b>  " . $row["email"]. "<br>";
                }
            } else {
                echo "0 results";
            }
            $conn->close();



           
           ?>  
           <!--  <td>dddddddddddddddd</td>
            <td>dddddddddddddddd</td>
            <td>dddddddddddddddd</td>
            <td>dddddddddddddddd</td>
            <td>dddddddddddddddd</td> -->
            
          

          </tbody>

        </form>
        
      </div>

      </table>
      </div>
      <div class="col-md-2">
        
      </div>
      
  </div>

  


</body>
</html>